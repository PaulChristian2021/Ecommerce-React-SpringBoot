package com.pyke.pcommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
